import { useState } from 'react'
import { Link } from 'react-router-dom'
import Brand from './Brand'
import Button from './ui/Button'
export default function Navbar(){
 const [open,setOpen]=useState(false)
 const links=[['Home','#home'],['About','#about'],['Features','#features'],['Contact','#contact']]
 return <header className="fixed inset-x-0 top-0 z-50 border-b border-white/40 bg-white/80 backdrop-blur-xl">
  <div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-3 lg:px-8"><Brand/>
   <nav className="hidden items-center gap-7 md:flex">{links.map(([n,h])=><a key={n} href={h} className="text-sm font-medium text-slate-600 hover:text-blue-600">{n}</a>)}<Button to="/login"><i className="ri-login-box-line"/> Login</Button></nav>
   <button className="text-2xl md:hidden" onClick={()=>setOpen(!open)} aria-label="Menu"><i className={open?'ri-close-line':'ri-menu-line'}/></button>
  </div>
  {open&&<nav className="border-t border-slate-100 bg-white px-5 pb-5 pt-3 md:hidden">{links.map(([n,h])=><a onClick={()=>setOpen(false)} key={n} href={h} className="block rounded-lg px-3 py-3 text-sm font-medium text-slate-600">{n}</a>)}<Button to="/login" className="mt-2 w-full"/></nav>}
 </header>
}