import { Link } from 'react-router-dom'
export default function Button({children,to,onClick,type="button",variant="primary",className=""}){
 const cls=`inline-flex items-center justify-center gap-2 rounded-full px-5 py-2.5 text-sm font-semibold transition-all duration-200 active:scale-95 ${variant==="primary"?"bg-blue-600 text-white shadow-lg shadow-blue-600/20 hover:bg-blue-700":"border border-slate-200 bg-white text-slate-700 hover:border-blue-300 hover:text-blue-600"} ${className}`
 return to?<Link to={to} className={cls}>{children}</Link>:<button type={type} onClick={onClick} className={cls}>{children}</button>
}