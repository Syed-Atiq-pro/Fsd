export default function Button({children,variant='primary',className='',...p}){return <button className={`btn btn-${variant} ${className}`} {...p}>{children}</button>}
