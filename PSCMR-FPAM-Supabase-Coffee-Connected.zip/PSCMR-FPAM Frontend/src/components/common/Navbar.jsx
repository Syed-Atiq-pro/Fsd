import { Link } from "react-router-dom";
export default function Navbar() {
  return (
    <header className="sticky top-0 z-30 border-b border-slate-200 bg-white/90 backdrop-blur">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4">
        <Link to="/" className="flex items-center gap-3">
          <img
            src="/src/assets/PSCMR-College-of-Engineering-Technology.png"
            className="h-10 w-10 object-contain"
          />
          <div>
            <b className="block text-sm">PSCMR</b>
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
              FPAM Portal
            </span>
          </div>
        </Link>
        <nav className="hidden gap-7 text-sm font-semibold text-slate-600 md:flex">
          <a href="#about">About</a>
          <a href="#features">Features</a>
          <a href="#workflow">Workflow</a>
        </nav>
        <Link to="/login" className="btn btn-primary">
          Portal Login <i className="ri-login-box-line" />
        </Link>
      </div>
    </header>
  );
}
