import { Link } from 'react-router-dom'
import logo from '../assets/PSCMR-College-of-Engineering-Technology.png'
export default function Brand({dark=false}){
 return <Link to="/" className="flex items-center gap-3">
  <img src={logo} className="h-11 w-11 object-contain" alt="PSCMR logo"/>
  <div><p className={`text-sm font-extrabold tracking-tight ${dark?'text-white':'text-slate-900'}`}>PSCMR</p><p className={`text-[10px] font-semibold tracking-widest ${dark?'text-blue-200':'text-slate-500'}`}>FPAM PORTAL</p></div>
 </Link>
}