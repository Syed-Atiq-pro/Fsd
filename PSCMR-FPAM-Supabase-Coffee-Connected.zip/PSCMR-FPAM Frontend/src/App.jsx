import {Routes,Route,Navigate,useLocation} from 'react-router-dom'
import Home from './pages/Home'
import Login from './pages/Login'
import Portal from './pages/Portal'
import {AuthProvider,useAuth} from './store/auth'
function Guard({children,role}){const {user,loading}=useAuth();const loc=useLocation();if(loading)return <div className="grid min-h-screen place-items-center bg-slate-50 text-sm font-semibold text-slate-500">Checking secure session...</div>;if(!user)return <Navigate to="/login" state={{from:loc.pathname}} replace/>;if(role&&user.role!==role)return <Navigate to="/portal" replace/>;return children}
export default function App(){return <AuthProvider><Routes><Route path="/" element={<Home/>}/><Route path="/login" element={<Login/>}/><Route path="/portal" element={<Guard><Portal/></Guard>}/><Route path="/admin/*" element={<Guard role="admin"><Portal/></Guard>}/><Route path="/faculty/*" element={<Guard role="faculty"><Portal/></Guard>}/><Route path="*" element={<Navigate to="/" replace/>}/></Routes></AuthProvider>}
