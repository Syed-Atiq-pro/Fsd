import { useEffect, useMemo, useState } from 'react'
import Button from '../components/common/Button'
import Modal from '../components/common/Modal'
import { deleteRecord, insertRecord, listRecords, updateRecord } from '../store/db'
import { useAuth } from '../store/auth'

export default function CrudTable({ title, description, dbKey, fields, columns, canDelete=true }) {
  const { user } = useAuth()
  const [rows,setRows]=useState([])
  const [loading,setLoading]=useState(true)
  const [q,setQ]=useState('')
  const [editing,setEditing]=useState(null)
  const [form,setForm]=useState({})
  const [open,setOpen]=useState(false)
  const [error,setError]=useState('')

  const load=async()=>{
    setLoading(true);setError('')
    try{setRows(await listRecords(dbKey))}catch(e){setError(e.message||'Unable to load records.')}finally{setLoading(false)}
  }
  useEffect(()=>{load()},[dbKey])

  const filtered=useMemo(()=>rows.filter(r=>Object.values(r).some(v=>String(v??'').toLowerCase().includes(q.toLowerCase()))),[rows,q])
  const start=(row=null)=>{
    setError('');setEditing(row)
    setForm(row?{...row}:Object.fromEntries(fields.map(f=>[f.key,f.default??''])))
    setOpen(true)
  }
  const save=async()=>{
    if(fields.some(f=>f.required&&!String(form[f.key]??'').trim()))return setError('Please fill all required fields.')
    setError('')
    try{
      if(editing) await updateRecord(dbKey,editing.id,form)
      else await insertRecord(dbKey,form,user.id)
      setOpen(false);await load()
    }catch(e){setError(e.message||'Unable to save this record.')}
  }
  const remove=async id=>{
    if(!confirm('Delete this record?'))return
    try{await deleteRecord(dbKey,id);await load()}catch(e){setError(e.message||'Unable to delete this record.')}
  }

  return <div className="fade">
    <div className="mb-5 flex flex-col gap-3 md:flex-row md:items-end md:justify-between"><div><h2 className="text-2xl font-black">{title}</h2><p className="mt-1 text-sm text-slate-500">{description}</p></div><Button onClick={()=>start()}><i className="ri-add-line"/>Add New</Button></div>
    {error&&!open&&<div className="mb-4 rounded-xl bg-red-50 p-3 text-sm font-semibold text-red-700">{error}</div>}
    <div className="card overflow-hidden">
      <div className="flex items-center justify-between gap-3 border-b border-slate-200 p-4"><div className="relative max-w-md flex-1"><i className="ri-search-line absolute left-3 top-3 text-slate-400"/><input className="input pl-9" placeholder="Search records..." value={q} onChange={e=>setQ(e.target.value)}/></div><button onClick={load} className="rounded-xl border border-slate-200 px-3 py-2 text-sm font-bold hover:bg-slate-50"><i className="ri-refresh-line"/></button></div>
      <div className="overflow-auto"><table className="w-full min-w-[760px] text-left text-sm"><thead className="bg-slate-50 text-xs uppercase tracking-wide text-slate-500"><tr>{columns.map(c=><th key={c.key} className="px-5 py-3">{c.label}</th>)}<th className="px-5 py-3 text-right">Actions</th></tr></thead><tbody className="divide-y divide-slate-100">
      {loading?<tr><td colSpan={columns.length+1} className="px-5 py-12 text-center text-slate-400">Loading from Supabase...</td></tr>:filtered.map(r=><tr key={r.id} className="hover:bg-slate-50">{columns.map(c=><td key={c.key} className="px-5 py-4">{c.render?c.render(r[c.key],r):r[c.key]}</td>)}<td className="px-5 py-4 text-right"><button onClick={()=>start(r)} className="mr-2 rounded-lg p-2 text-blue-600 hover:bg-blue-50"><i className="ri-edit-line"/></button>{canDelete&&<button onClick={()=>remove(r.id)} className="rounded-lg p-2 text-red-600 hover:bg-red-50"><i className="ri-delete-bin-line"/></button>}</td></tr>)}{!loading&&!filtered.length&&<tr><td colSpan={columns.length+1} className="px-5 py-12 text-center text-slate-400">No records found.</td></tr>}</tbody></table></div>
      <div className="border-t border-slate-200 px-5 py-3 text-xs text-slate-400">Showing {filtered.length} of {rows.length} records • Supabase database</div>
    </div>
    <Modal open={open} onClose={()=>setOpen(false)} title={editing?'Edit record':`Add ${title.replace(/s$/,'')}`}><div className="grid gap-4 sm:grid-cols-2">{fields.map(f=><label key={f.key} className={`text-sm font-semibold ${f.full?'sm:col-span-2':''}`}>{f.label}{f.type==='select'?<select className="input mt-1" value={form[f.key]??''} onChange={e=>setForm({...form,[f.key]:e.target.value})}><option value="">Select</option>{f.options.map(o=><option key={o} value={o}>{o}</option>)}</select>:f.type==='textarea'?<textarea rows="4" className="input mt-1" value={form[f.key]??''} onChange={e=>setForm({...form,[f.key]:e.target.value})}/>:<input type={f.type||'text'} className="input mt-1" value={form[f.key]??''} onChange={e=>setForm({...form,[f.key]:e.target.value})}/>}</label>)}</div>{error&&<p className="mt-4 rounded-lg bg-red-50 p-3 text-sm font-semibold text-red-700">{error}</p>}<div className="mt-6 flex justify-end gap-2"><Button variant="secondary" onClick={()=>setOpen(false)}>Cancel</Button><Button onClick={save}>Save Record</Button></div></Modal>
  </div>
}
