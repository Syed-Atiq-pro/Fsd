import {useEffect,useState} from 'react'
import {getProfile,updateProfile} from '../store/db'
import {useAuth} from '../store/auth'
import Button from '../components/common/Button'

export default function Profile(){
  const {user}=useAuth();const [form,setForm]=useState({});const [loading,setLoading]=useState(true);const [saving,setSaving]=useState(false);const [message,setMessage]=useState('');
  useEffect(()=>{getProfile(user.id).then(setForm).catch(e=>setMessage(e.message)).finally(()=>setLoading(false))},[user.id])
  const save=async()=>{setSaving(true);setMessage('');try{const next=await updateProfile(user.id,form);setForm(next);setMessage('Profile updated successfully.')}catch(e){setMessage(e.message||'Unable to update profile.')}finally{setSaving(false)}}
  if(loading)return <div className="card p-8 text-sm text-slate-500">Loading your profile from Supabase...</div>
  return <div className="fade max-w-4xl"><div className="mb-5"><h2 className="text-2xl font-black">My Profile</h2><p className="mt-1 text-sm text-slate-500">Maintain your official faculty information.</p></div><div className="card p-5 md:p-7"><div className="mb-7 flex items-center gap-4"><div className="grid h-16 w-16 place-items-center rounded-2xl bg-blue-600 text-xl font-black text-white">{form.name?.[0]}</div><div><h3 className="text-lg font-black">{form.name}</h3><p className="text-sm text-slate-500">{form.designation} • {form.department}</p></div></div><div className="grid gap-4 md:grid-cols-2">{['name','employeeId','department','designation','email','phone','qualification','specialization'].map(k=><label key={k} className="text-sm font-semibold capitalize">{k.replace(/([A-Z])/g,' $1')}<input className="input mt-1" value={form[k]||''} onChange={e=>setForm({...form,[k]:e.target.value})}/></label>)}</div>{message&&<p className="mt-4 rounded-lg bg-blue-50 p-3 text-sm font-semibold text-blue-800">{message}</p>}<div className="mt-6 flex justify-end"><Button disabled={saving} onClick={save}><i className="ri-save-line"/>{saving?'Saving...':'Save Profile'}</Button></div></div></div>
}
