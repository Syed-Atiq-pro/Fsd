import { createContext, useContext, useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'

const C = createContext(null)

async function loadUser(session) {
  if (!session?.user) return null
  const { data, error } = await supabase
    .from('pscmr_profiles')
    .select('*')
    .eq('id', session.user.id)
    .maybeSingle()

  if (error) throw error
  if (!data) return null

  return {
    id: session.user.id,
    email: session.user.email,
    role: data.role,
    name: data.full_name || session.user.email?.split('@')[0] || 'User',
    ...data
  }
}

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    let mounted = true
    supabase.auth.getSession().then(async ({ data }) => {
      try {
        const next = await loadUser(data.session)
        if (mounted) setUser(next)
      } catch (e) {
        console.error('Unable to load PSCMR profile:', e)
      } finally {
        if (mounted) setLoading(false)
      }
    })

    const { data: listener } = supabase.auth.onAuthStateChange(async (_event, session) => {
      try {
        const next = await loadUser(session)
        if (mounted) setUser(next)
      } catch (e) {
        console.error('Unable to load PSCMR profile:', e)
        if (mounted) setUser(null)
      } finally {
        if (mounted) setLoading(false)
      }
    })

    return () => {
      mounted = false
      listener.subscription.unsubscribe()
    }
  }, [])

  const login = async (email, password) => {
    const { data, error } = await supabase.auth.signInWithPassword({ email: email.trim(), password })
    if (error) return { ok: false, error: error.message }
    try {
      const next = await loadUser(data.session)
      if (!next) return { ok: false, error: 'Your account does not have a PSCMR profile yet.' }
      setUser(next)
      return { ok: true, user: next }
    } catch (e) {
      return { ok: false, error: e.message }
    }
  }

  const logout = async () => {
    await supabase.auth.signOut()
    setUser(null)
  }

  return <C.Provider value={{ user, loading, login, logout }}>{children}</C.Provider>
}

export function useAuth() { return useContext(C) }
