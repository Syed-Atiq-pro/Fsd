import { supabase } from '../lib/supabase'

const tableMap = {
  faculty: { table: 'pscmr_faculty', toUi: r => ({ id:r.employee_id, name:r.name, department:r.department, designation:r.designation, email:r.email, phone:r.phone, status:r.status }), fromUi: r => ({ employee_id:r.id, name:r.name, department:r.department, designation:r.designation, email:r.email, phone:r.phone, status:r.status }) },
  departments: { table: 'pscmr_departments', toUi: r => ({ id:r.id, name:r.name, code:r.code, hod:r.hod, faculty:r.faculty_count }), fromUi: r => ({ name:r.name, code:r.code, hod:r.hod, faculty_count:Number(r.faculty ?? 0) }) },
  activities: { table: 'pscmr_activities', toUi: r => ({ id:r.id, title:r.title, faculty:r.faculty, department:r.department, date:r.activity_date, type:r.type, status:r.status, description:r.description, created_by:r.created_by }), fromUi: r => ({ title:r.title, faculty:r.faculty, department:r.department, activity_date:r.date, type:r.type, status:r.status, description:r.description }) },
  documents: { table: 'pscmr_documents', toUi: r => ({ id:r.id, name:r.name, owner:r.owner, category:r.category, date:r.document_date, status:r.status, file_url:r.file_url, created_by:r.created_by }), fromUi: r => ({ name:r.name, owner:r.owner, category:r.category, document_date:r.date, status:r.status, file_url:r.file_url }) },
  aspirants: { table: 'pscmr_aspirants', toUi: r => ({ id:r.id, student:r.student, roll:r.roll, department:r.department, guide:r.guide, topic:r.topic, status:r.status, progress:r.progress, created_by:r.created_by }), fromUi: r => ({ student:r.student, roll:r.roll, department:r.department, guide:r.guide, topic:r.topic, status:r.status, progress:Number(r.progress ?? 0) }) }
}

export async function listRecords(dbKey) {
  const cfg = tableMap[dbKey]
  if (!cfg) throw new Error(`Unknown data collection: ${dbKey}`)
  const { data, error } = await supabase.from(cfg.table).select('*').order('created_at', { ascending:false })
  if (error) throw error
  return (data || []).map(cfg.toUi)
}

export async function insertRecord(dbKey, values, userId) {
  const cfg = tableMap[dbKey]
  const payload = cfg.fromUi(values)
  if (['activities','documents','aspirants'].includes(dbKey)) payload.created_by = userId
  const { data, error } = await supabase.from(cfg.table).insert(payload).select('*').single()
  if (error) throw error
  return cfg.toUi(data)
}

export async function updateRecord(dbKey, id, values) {
  const cfg = tableMap[dbKey]
  const payload = cfg.fromUi(values)
  if (dbKey === 'faculty') {
    const { data, error } = await supabase.from(cfg.table).update(payload).eq('employee_id', id).select('*').single()
    if (error) throw error
    return cfg.toUi(data)
  }
  const { data, error } = await supabase.from(cfg.table).update(payload).eq('id', id).select('*').single()
  if (error) throw error
  return cfg.toUi(data)
}

export async function deleteRecord(dbKey, id) {
  const cfg = tableMap[dbKey]
  const column = dbKey === 'faculty' ? 'employee_id' : 'id'
  const { error } = await supabase.from(cfg.table).delete().eq(column, id)
  if (error) throw error
}

export async function getDashboardDB() {
  const keys = ['faculty','departments','activities','documents','aspirants']
  const result = {}
  for (const key of keys) result[key] = await listRecords(key)
  return result
}

export async function getProfile(userId) {
  const { data, error } = await supabase.from('pscmr_profiles').select('*').eq('id', userId).single()
  if (error) throw error
  return { ...data, name:data.full_name, employeeId:data.employee_id }
}

export async function updateProfile(userId, form) {
  const payload = {
    full_name: form.name,
    employee_id: form.employeeId,
    department: form.department,
    designation: form.designation,
    email: form.email,
    phone: form.phone,
    qualification: form.qualification,
    specialization: form.specialization
  }
  const { data, error } = await supabase.from('pscmr_profiles').update(payload).eq('id', userId).select('*').single()
  if (error) throw error
  return { ...data, name:data.full_name, employeeId:data.employee_id }
}
