import { Link } from "react-router-dom";
import Navbar from "../components/common/Navbar";
import Footer from "../components/common/Footer";
const features = [
  [
    "ri-team-line",
    "Faculty Management",
    "Maintain faculty profiles, departments, designations and status.",
  ],
  [
    "ri-calendar-check-line",
    "Activity Management",
    "Create, edit and monitor academic activities with approval status.",
  ],
  [
    "ri-user-star-line",
    "Aspirant Tracking",
    "Track assigned students, research topics and project progress.",
  ],
  [
    "ri-folder-3-line",
    "Document Records",
    "Maintain document metadata and verification status.",
  ],
  [
    "ri-bar-chart-box-line",
    "Reports",
    "Export live portal records to CSV for administrative review.",
  ],
  [
    "ri-shield-check-line",
    "Role Based Access",
    "Separate admin and faculty workspaces with protected routes.",
  ],
];
export default function Home() {
  return (
    <>
      <Navbar />
      <main>
        <section className="bg-blue-300 text-white">
          <div className="mx-auto grid max-w-7xl items-center gap-12 px-5 py-20 lg:grid-cols-2 lg:py-28">
            <div>
              <span className="badge bg-blue-500/20 text-blue-200">
                PSCMR • FPAM
              </span>
              <h1 className="mt-5 text-4xl font-black tracking-tight md:text-6xl">
                Faculty Performance & Academic Management Portal
              </h1>
              <p
                className="mt-6 max-w-xl text-base leading-7 text-green
              -300"
              >
                A structured digital workspace for faculty records, academic
                activities, documents, aspirant guidance and institutional
                reporting.
              </p>
              <div className="mt-8 flex flex-wrap gap-3">
                <Link to="/login" className="btn btn-primary">
                  Open Portal <i className="ri-arrow-right-line" />
                </Link>
                <a
                  href="#features"
                  className="btn border border-white/20 bg-white/10 text-white"
                >
                  Explore Features
                </a>
              </div>
            </div>
            <div className="overflow-hidden rounded-3xl border border-white/10 bg-white/5 p-3 shadow-2xl">
              <img
                src="/src/assets/PSCMR.jpg"
                className="h-[340px] w-full rounded-2xl object-cover"
              />
            </div>
          </div>
        </section>
        <section id="about" className="mx-auto max-w-7xl px-5 py-20">
          <div className="max-w-2xl">
            <span className="text-xs font-black uppercase tracking-[.2em] text-blue-600">
              About the portal
            </span>
            <h2 className="mt-3 text-3xl font-black md:text-4xl">
              One workspace for everyday faculty administration.
            </h2>
            <p className="mt-4 leading-7 text-slate-500">
              FPAM organizes recurring academic management tasks into clear
              modules. Records can be created, edited, searched and exported
              without navigating through disconnected spreadsheets.
            </p>
          </div>
        </section>
        <section id="features" className="bg-slate-50">
          <div className="mx-auto max-w-7xl px-5 py-20">
            <div className="text-center">
              <span className="text-xs font-black uppercase tracking-[.2em] text-blue-600">
                Core modules
              </span>
              <h2 className="mt-3 text-3xl font-black">
                Built around actual workflows
              </h2>
            </div>
            <div className="mt-10 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
              {features.map((f) => (
                <div key={f[1]} className="card p-6">
                  <i className={`${f[0]} text-3xl text-blue-600`} />
                  <h3 className="mt-5 font-black">{f[1]}</h3>
                  <p className="mt-2 text-sm leading-6 text-slate-500">
                    {f[2]}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </section>
        <section id="workflow" className="mx-auto max-w-7xl px-5 py-20">
          <div className="card grid gap-8 p-7 md:grid-cols-3 md:p-10">
            <div>
              <b className="text-blue-600">01</b>
              <h3 className="mt-3 font-black">Sign in</h3>
              <p className="mt-2 text-sm text-slate-500">
                Admin and faculty access different workspaces.
              </p>
            </div>
            <div>
              <b className="text-blue-600">02</b>
              <h3 className="mt-3 font-black">Manage records</h3>
              <p className="mt-2 text-sm text-slate-500">
                Add, edit, search and remove records through forms.
              </p>
            </div>
            <div>
              <b className="text-blue-600">03</b>
              <h3 className="mt-3 font-black">Review & export</h3>
              <p className="mt-2 text-sm text-slate-500">
                Administrators can export current records for review.
              </p>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
