# PSCMR FPAM Frontend + Supabase

This version is connected to the existing Supabase project **coffee-shop-platform** (project ref `sliehgjfreorikxhrjfj`). The existing coffee tables were preserved; PSCMR uses its own `pscmr_*` tables in the same database.

## Setup

```bash
npm install
npm run dev
```

The supplied `.env.local` is already configured for the selected Supabase project. For another environment, copy `.env.example` to `.env.local` and add the project's publishable key.

## Supabase integration

- Supabase Auth handles login sessions.
- `pscmr_profiles` stores the portal role and faculty profile.
- PostgreSQL stores faculty, departments, activities, documents and aspirants.
- Row Level Security protects the tables.
- New Auth users automatically receive a PSCMR faculty profile.
- New users are **faculty by default**. An administrator must be promoted in SQL.

## Create accounts

In Supabase Dashboard → Authentication → Users, create the required email/password accounts.

After creating the administrator account, run:

```sql
update public.pscmr_profiles
set role = 'admin'
where email = 'YOUR_ADMIN_EMAIL';
```

Faculty accounts remain `faculty` by default.

## Important

Do not put a service-role/secret key in the frontend. The frontend uses the Supabase publishable key only.
